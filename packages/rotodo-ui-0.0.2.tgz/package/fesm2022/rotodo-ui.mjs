import * as i0 from '@angular/core';
import { Injectable, Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

class UiService {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UiService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UiService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class UiComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UiComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: UiComponent, isStandalone: true, selector: "lib-ui", ngImport: i0, template: `
    <p>
      ui works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: UiComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-ui', standalone: true, imports: [], template: `
    <p>
      ui works!
    </p>
  ` }]
        }] });

class ToggleSwitchComponent {
    color = '#2563eb';
    size = 'md';
    disabled = false;
    checked = false;
    // EventEmitter برای ارسال وضعیت به والد
    toggleChange = new EventEmitter();
    onToggle(event) {
        if (!this.disabled) {
            const inputElement = event.target;
            this.checked = inputElement.checked;
            this.toggleChange.emit(this.checked);
        }
    }
    get sizeClasses() {
        const sizes = {
            sm: 'w-9 h-5 after:h-4 after:h-4', // اصلاح سایز دایره کوچک
            md: 'w-11 h-6 after:h-5 after:h-5',
            lg: 'w-14 h-7 after:h-6 after:h-6'
        };
        return sizes[this.size];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ToggleSwitchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: ToggleSwitchComponent, isStandalone: true, selector: "lib-toggle-switch", inputs: { color: "color", size: "size", disabled: "disabled", checked: "checked" }, outputs: { toggleChange: "toggleChange" }, ngImport: i0, template: `
    <label class="relative inline-flex items-center" 
           [class.cursor-pointer]="!disabled" 
           [class.opacity-50]="disabled">
      
      <input type="checkbox" 
             class="sr-only peer" 
             [checked]="checked" 
             [disabled]="disabled"
             (change)="onToggle($event)">
      
      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full 
                  peer peer-checked:after:translate-x-full peer-checked:after:border-white 
                  after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                  after:bg-white after:border-gray-300 after:border after:rounded-full 
                  after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"
           [class]="sizeClasses"
           [style.--toggle-color]="color">
      </div>
    </label>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: ToggleSwitchComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-toggle-switch',
                    standalone: true,
                    imports: [CommonModule],
                    template: `
    <label class="relative inline-flex items-center" 
           [class.cursor-pointer]="!disabled" 
           [class.opacity-50]="disabled">
      
      <input type="checkbox" 
             class="sr-only peer" 
             [checked]="checked" 
             [disabled]="disabled"
             (change)="onToggle($event)">
      
      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full 
                  peer peer-checked:after:translate-x-full peer-checked:after:border-white 
                  after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                  after:bg-white after:border-gray-300 after:border after:rounded-full 
                  after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"
           [class]="sizeClasses"
           [style.--toggle-color]="color">
      </div>
    </label>
  `
                }]
        }], propDecorators: { color: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], checked: [{
                type: Input
            }], toggleChange: [{
                type: Output
            }] } });

class StepperComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: StepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: StepperComponent, isStandalone: true, selector: "lib-stepper", ngImport: i0, template: "<div complete-verification-steps-grid class=\"grid grid-cols-3 gap-4\">\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div\n            class=\"w-10 h-10 rounded-full bg-green-500 outline-green-500 outline outline-1 outline-green-500 border-[5px] border-white flex items-center justify-center\">\n            <svg class=\"w-6 h-6 text-white\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\"\n                xmlns=\"http://www.w3.org/2000/svg\">\n                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"3\" d=\"M5 13l4 4L19 7\"></path>\n            </svg>\n        </div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-800 whitespace-nowrap\">\u0646\u0648\u0639 \u06A9\u0627\u0631\u0628\u0631</p>\n            <p class=\"text-xs text-gray-500 mt-1 whitespace-nowrap\">\u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0648\u0639 \u06A9\u0627\u0631\u0628\u0631</p>\n        </div>\n    </div>\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div class=\"absolute w-[75%] h-[3px] rounded-[2px] top-[32px] left-[65%] border-2 border-green-500\"></div>\n        <div\n            class=\"relative w-10 h-10 rounded-full bg-blue-500 outline-blue-500 outline outline-1 outline-blue-500 border-[5px] border-white flex items-center justify-center text-white font-bold\">\n            \u06F2\n        </div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-800 whitespace-nowrap\">\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0647\u0648\u06CC\u062A\u06CC \u0648 \u062A\u0645\u0627\u0633</p>\n            <p class=\"text-xs text-gray-500 mt-1 whitespace-nowrap\">\u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0646 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0647\u0648\u06CC\u062A\u06CC \u0648 \u062A\u0645\u0627\u0633</p>\n        </div>\n    </div>\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div\n            class=\"absolute w-[75%] h-[3px] rounded-[2px] top-[32px] left-[65%] border-gray-200 border-2 border-dashed\">\n        </div>\n        <div\n            class=\"w-10 h-10 rounded-full border-2 border-gray-100 flex items-center justify-center text-gray-400 bg-gray-100 font-bold\">\n            \u06F3</div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-400 whitespace-nowrap\">\u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A</p>\n            <p class=\"text-xs text-gray-400 mt-1 whitespace-nowrap\">\u0628\u0627\u0632\u0628\u06CC\u0646\u06CC \u0648 \u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A</p>\n        </div>\n    </div>\n</div>", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: StepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-stepper', standalone: true, imports: [], template: "<div complete-verification-steps-grid class=\"grid grid-cols-3 gap-4\">\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div\n            class=\"w-10 h-10 rounded-full bg-green-500 outline-green-500 outline outline-1 outline-green-500 border-[5px] border-white flex items-center justify-center\">\n            <svg class=\"w-6 h-6 text-white\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\"\n                xmlns=\"http://www.w3.org/2000/svg\">\n                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"3\" d=\"M5 13l4 4L19 7\"></path>\n            </svg>\n        </div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-800 whitespace-nowrap\">\u0646\u0648\u0639 \u06A9\u0627\u0631\u0628\u0631</p>\n            <p class=\"text-xs text-gray-500 mt-1 whitespace-nowrap\">\u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0648\u0639 \u06A9\u0627\u0631\u0628\u0631</p>\n        </div>\n    </div>\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div class=\"absolute w-[75%] h-[3px] rounded-[2px] top-[32px] left-[65%] border-2 border-green-500\"></div>\n        <div\n            class=\"relative w-10 h-10 rounded-full bg-blue-500 outline-blue-500 outline outline-1 outline-blue-500 border-[5px] border-white flex items-center justify-center text-white font-bold\">\n            \u06F2\n        </div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-800 whitespace-nowrap\">\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0647\u0648\u06CC\u062A\u06CC \u0648 \u062A\u0645\u0627\u0633</p>\n            <p class=\"text-xs text-gray-500 mt-1 whitespace-nowrap\">\u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0646 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0647\u0648\u06CC\u062A\u06CC \u0648 \u062A\u0645\u0627\u0633</p>\n        </div>\n    </div>\n    <div class=\"flex flex-col p-4 items-center relative\">\n        <div\n            class=\"absolute w-[75%] h-[3px] rounded-[2px] top-[32px] left-[65%] border-gray-200 border-2 border-dashed\">\n        </div>\n        <div\n            class=\"w-10 h-10 rounded-full border-2 border-gray-100 flex items-center justify-center text-gray-400 bg-gray-100 font-bold\">\n            \u06F3</div>\n        <div class=\"text-center mt-3\">\n            <p class=\"text-sm font-bold text-gray-400 whitespace-nowrap\">\u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A</p>\n            <p class=\"text-xs text-gray-400 mt-1 whitespace-nowrap\">\u0628\u0627\u0632\u0628\u06CC\u0646\u06CC \u0648 \u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A</p>\n        </div>\n    </div>\n</div>" }]
        }] });

/*
 * Public API Surface of ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { StepperComponent, ToggleSwitchComponent, UiComponent, UiService };
//# sourceMappingURL=rotodo-ui.mjs.map
